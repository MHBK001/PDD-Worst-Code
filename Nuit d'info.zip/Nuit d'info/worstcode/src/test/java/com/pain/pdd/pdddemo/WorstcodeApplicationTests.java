package com.pain.pdd.pdddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorstcodeApplicationTests {

    @Test
    void contextLoads() {
    }

}
